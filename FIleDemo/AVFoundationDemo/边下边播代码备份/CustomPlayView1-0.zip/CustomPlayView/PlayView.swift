//
//  PlayView.swift
//  AVFoundationDemo
//
//  Created by apple on 2022/1/4.
//

import Foundation
import UIKit
import AVFoundation

//MARK: - Define
class PlayerView:UIView {
    override class var layerClass: AnyClass {
        return AVPlayerLayer.self
    }
    
    
    var player:AVPlayer? {
        set {
            playerLayer.player = newValue
        }
        
        get {
            return playerLayer.player
        }
    }
    
    fileprivate var playerLayer:AVPlayerLayer {
        return layer as! AVPlayerLayer
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.commonInit()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.commonInit()
    }
    
    func commonInit() {
        
    }
}

//MARK: - SubTypes
extension PlayerView {}

//MARK: - Override
extension PlayerView {}


//MARK: - Interface
extension PlayerView {}

//MARK: - Private
private extension PlayerView {}
